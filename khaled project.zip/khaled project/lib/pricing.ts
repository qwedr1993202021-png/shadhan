export type PriceTier = {
  id: "half" | "one" | "two";
  label: string;
  weight: string;
  price: number;
  priceLabel: string;
  offer?: boolean;
  offerLabel?: string;
  compareAt?: string;
};

export const PRICING: PriceTier[] = [
  {
    id: "half",
    label: "نصف كيلو",
    weight: "٥٠٠ جم",
    price: 18,
    priceLabel: "١٨ دينار",
  },
  {
    id: "one",
    label: "كيلو واحد",
    weight: "١ كجم",
    price: 27,
    priceLabel: "٢٧ دينار",
  },
  {
    id: "two",
    label: "كيلوان",
    weight: "٢ كجم",
    price: 50,
    priceLabel: "٥٠ دينار",
    offer: true,
    offerLabel: "عرض خاص",
    compareAt: "٥٤ دينار",
  },
];
