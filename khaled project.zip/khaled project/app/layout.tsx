import type { Metadata } from "next";
import localFont from "next/font/local";
import { Poppins, Tajawal } from "next/font/google";
import "lenis/dist/lenis.css";
import "./globals.css";
import SmoothScroll from "@/components/SmoothScroll";

const poppins = Poppins({
  subsets: ["latin"],
  weight: ["400", "600", "800"],
  variable: "--font-poppins",
  display: "swap",
});

const tajawal = Tajawal({
  subsets: ["arabic"],
  weight: ["400", "500", "700", "800", "900"],
  variable: "--font-tajawal",
  display: "swap",
});

const naveid = localFont({
  src: "../public/fonts/naveid-arabic-demo.extra-bold.otf",
  variable: "--font-naveid",
  display: "swap",
});

export const metadata: Metadata = {
  title: "شدهان للعسل | عسل الطلح البلدي",
  description:
    "عسل الطلح البلدي الفاخر من شدهان للعسل — طبيعي ١٠٠٪، حائز على جوائز عالمية في باريس ولندن وأبوظبي. نكهة الأصالة من أرض المملكة.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ar" dir="rtl" className={`${poppins.variable} ${tajawal.variable} ${naveid.variable}`}>
      <body><SmoothScroll>{children}</SmoothScroll></body>
    </html>
  );
}
