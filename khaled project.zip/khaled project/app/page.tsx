import Navbar from "@/components/Navbar";
import FloatingBees from "@/components/FloatingBees";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import AwardsSection from "@/components/AwardsSection";
import WhySection from "@/components/WhySection";
import ProductsSection from "@/components/ProductsSection";
import CertificateSection from "@/components/CertificateSection";
import ProcessSection from "@/components/ProcessSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import OrderForm from "@/components/OrderForm";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <FloatingBees />
      <main className="relative">
        <HeroSection />
        <AboutSection />
        <AwardsSection />
        <WhySection />
        <ProductsSection />
        <CertificateSection />
        <ProcessSection />
        <TestimonialsSection />
        <OrderForm />
        <Footer />
      </main>
    </>
  );
}
