"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import OrderButton from "@/components/OrderButton";

const navLinks = [
  { label: "عن شدهان", href: "#about" },
  { label: "المنتجات", href: "#products" },
  { label: "الجوائز", href: "#awards" },
  { label: "الجودة", href: "#certificate" },
  { label: "آراء العملاء", href: "#testimonials" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close menu on orientation change
  useEffect(() => {
    const close = () => setOpen(false);
    window.addEventListener("orientationchange", close);
    return () => window.removeEventListener("orientationchange", close);
  }, []);

  const handleLinkClick = (href: string) => {
    setOpen(false);
    const lenis = (window as any).lenis;
    if (lenis) {
      lenis.scrollTo(href, { offset: -88 });
    }
  };

  return (
    <nav
      className={`glass-nav fixed top-0 inset-x-0 z-50 ${
        scrolled ? "glass-nav--scrolled" : ""
      }`}
    >
      <div className="container-site flex items-center justify-between h-16 md:h-20 lg:h-[88px]">
        {/* Wordmark (right side in RTL) */}
        <a href="#" className="flex items-center no-underline" aria-label="شدهان للعسل">
          <Image
            src="/brand/logo.png"
            alt="شدهان للعسل"
            width={150}
            height={48}
            priority
            className="h-9 md:h-10 lg:h-12 w-auto object-contain"
          />
        </a>

        {/* Center links — desktop only */}
        <div className="hidden md:flex items-center gap-7">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                handleLinkClick(link.href);
              }}
              className="text-[17px] font-bold text-dark/95 no-underline transition-all duration-300 ease-out hover:text-honey hover:scale-110 inline-block"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* CTA + hamburger */}
        <div className="flex items-center gap-3">
          <div className="hidden md:block"><OrderButton href="#contact" /></div>
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden flex flex-col gap-1.5 p-2 bg-transparent border-none cursor-pointer min-w-[44px] min-h-[44px] items-center justify-center"
            aria-label="القائمة"
            aria-expanded={open}
          >
            <span className={`block w-5 h-0.5 bg-dark transition-transform duration-200 ${open ? "rotate-45 translate-y-[5px]" : ""}`} />
            <span className={`block w-5 h-0.5 bg-dark transition-opacity duration-200 ${open ? "opacity-0" : ""}`} />
            <span className={`block w-5 h-0.5 bg-dark transition-transform duration-200 ${open ? "-rotate-45 -translate-y-[5px]" : ""}`} />
          </button>
        </div>
      </div>

      {/* Mobile dropdown */}
      {open && (
        <div className="md:hidden glass-nav--scrolled border-t border-dark/8 pb-4 max-h-[calc(100dvh-64px)] overflow-y-auto">
          <div className="container-site flex flex-col gap-1 pt-3">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  handleLinkClick(link.href);
                }}
                className="text-[17px] font-bold text-dark/95 no-underline hover:text-dark py-3 px-2 rounded-lg hover:bg-cream/50 transition-colors min-h-[44px] flex items-center"
              >
                {link.label}
              </a>
            ))}
            <div className="mt-3 py-2">
              <OrderButton href="#contact" />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}
