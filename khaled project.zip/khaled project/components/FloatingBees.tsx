"use client";

import { useEffect, useState } from "react";
import type { CSSProperties } from "react";

const bees: Array<{
  style: CSSProperties;
  anim: string;
  size: number;
  src: string;
  sectionIndex: number;
}> = [
  { style: { top: "14%", left: "8%" }, anim: "animate-float-slow", size: 26, src: "https://cdn.prod.website-files.com/6635cb7981c78be748c6d975/6655a5bf56aa34b9561ed709_2.png", sectionIndex: 0 },
  { style: { top: "42%", right: "6%" }, anim: "animate-drift", size: 22, src: "https://cdn.prod.website-files.com/6635cb7981c78be748c6d975/66545308308ecc39b682d6bf_1.png", sectionIndex: 1 },
  { style: { top: "68%", left: "12%" }, anim: "animate-float-slower", size: 24, src: "https://cdn.prod.website-files.com/6635cb7981c78be748c6d975/6655a5bf56aa34b9561ed709_2.png", sectionIndex: 2 },
  { style: { top: "86%", right: "14%" }, anim: "animate-float-slow", size: 19, src: "https://cdn.prod.website-files.com/6635cb7981c78be748c6d975/66545308308ecc39b682d6bf_1.png", sectionIndex: 3 },
];

export default function FloatingBees() {
  const [opacities, setOpacities] = useState<number[]>([1, 1, 1, 1]);

  useEffect(() => {
    const update = () => {
      const sections = document.querySelectorAll("section");
      if (!sections.length) return;
      const vh = window.innerHeight;
      const center = vh / 2;
      const next = bees.map((bee) => {
        const el = sections[Math.min(bee.sectionIndex, sections.length - 1)];
        if (!el) return 0;
        const rect = el.getBoundingClientRect();
        const dist = Math.abs(rect.top + rect.height / 2 - center);
        return 1 - Math.min(1, dist / (vh * 1.5));
      });
      setOpacities(next);
    };

    let ticking = false;
    const onScroll = () => {
      if (!ticking) {
        requestAnimationFrame(() => { update(); ticking = false; });
        ticking = true;
      }
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    update();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden>
      {bees.map((b, i) => (
        <div
          key={i}
          className={`absolute ${b.anim} ${i >= 2 ? "hidden sm:block" : ""}`}
          style={{ ...b.style, opacity: opacities[i], transition: "opacity 0.5s ease" }}
        >
          <img src={b.src} alt="" width={b.size} height={b.size} className="w-auto h-auto sm:scale-100 scale-75" />
        </div>
      ))}
    </div>
  );
}
