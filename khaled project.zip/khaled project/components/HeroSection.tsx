"use client";

import type { CSSProperties } from "react";
import HoneyScrollSequence from "@/components/HoneyScrollSequence";
import OrderButton from "@/components/OrderButton";

const scrimStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  pointerEvents: "none",
  background:
    "linear-gradient(to top, rgba(58,45,28,0.66) 0%, rgba(58,45,28,0.28) 26%, rgba(58,45,28,0) 52%)",
  zIndex: 0,
};

const glowStyle: CSSProperties = {
  position: "absolute",
  width: "min(92vw, 760px)",
  height: "min(92vw, 760px)",
  borderRadius: "50%",
  background:
    "radial-gradient(circle, rgba(248,203,20,0.16) 0%, rgba(248,203,20,0.06) 42%, transparent 70%)",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  pointerEvents: "none",
};

const overlayStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  display: "flex",
  alignItems: "flex-end",
  justifyContent: "center",
  pointerEvents: "none",
  padding: "0 1.5rem clamp(3.5rem, 10vh, 7rem)",
};

const contentStyle: CSSProperties = {
  textAlign: "center",
  pointerEvents: "none",
  maxWidth: "48rem",
  position: "relative",
  zIndex: 2,
};

const headlineStyle: CSSProperties = {
  fontSize: "clamp(2rem, 7vw, 5rem)",
  lineHeight: 1.1,
  fontWeight: 800,
  color: "#FFF8EE",
  textShadow: "0 2px 22px rgba(0,0,0,0.55), 0 1px 3px rgba(0,0,0,0.45)",
};

const subStyle: CSSProperties = {
  fontSize: "clamp(1rem, 2.2vw, 1.35rem)",
  color: "rgba(255,250,240,0.92)",
  textShadow: "0 1px 14px rgba(0,0,0,0.5)",
  opacity: 1,
  fontWeight: 500,
  maxWidth: "36rem",
  marginInline: "auto",
  lineHeight: 1.625,
};

const ctaWrapStyle: CSSProperties = {
  display: "flex",
  gap: "0.75rem",
  justifyContent: "center",
  flexWrap: "wrap",
  pointerEvents: "auto",
};

const scrollHintStyle: CSSProperties = {
  position: "absolute",
  bottom: "2.2rem",
  left: "50%",
  transform: "translateX(-50%)",
  fontSize: "0.85rem",
  color: "rgba(255,250,240,0.85)",
  pointerEvents: "none",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  gap: "0.4rem",
};

const underlineStyle: CSSProperties = {
  width: 56,
  height: 3,
  background: "#E8B511",
  borderRadius: 999,
  margin: "0.75rem auto 0",
};

const labelPillStyle: CSSProperties = {
  background: "rgba(58,45,28,0.45)",
  color: "#FFE9A8",
  backdropFilter: "blur(4px)",
};

const gradientSpanStyle: CSSProperties = {
  background: "linear-gradient(90deg,#FFD764,#E8B511)",
  WebkitBackgroundClip: "text",
  backgroundClip: "text",
  color: "transparent",
};

export default function HeroSection() {
  return (
    <section>
      <HoneyScrollSequence>
        <div style={overlayStyle}>
          <div style={scrimStyle} />
          <div style={glowStyle} />
          <div style={contentStyle} className="px-4 sm:px-6">
            <div className="flex flex-col items-center gap-4 sm:gap-5 md:gap-6">
              <span className="label-mustard" style={labelPillStyle}>
                عسل طبيعي ١٠٠٪ • شدهان للعسل
              </span>
              <div>
                <h1 style={headlineStyle}>
                  <span style={gradientSpanStyle}>
                    عسل
                  </span>{" "}
                  الطلح البلدي
                </h1>
                <div style={underlineStyle} />
              </div>
              <p style={subStyle}>
                نكهة الأصالة من أرض المملكة — من قلب الطبيعة إلى مائدتك
              </p>
              <div style={ctaWrapStyle} className="mt-1 sm:mt-2">
                <div className="w-full sm:w-auto scale-110"><OrderButton href="#contact" /></div>
                <a href="#products" className="btn-outline w-full sm:w-auto">تصفّح المنتجات</a>
              </div>
            </div>
          </div>
        </div>
        <div style={scrollHintStyle} className="text-xs sm:text-sm">
          <span>اسحب للأسفل</span>
          <span className="text-base sm:text-lg">↓</span>
        </div>
      </HoneyScrollSequence>
    </section>
  );
}
