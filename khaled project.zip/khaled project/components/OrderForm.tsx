"use client";

import { useState, type FormEvent, useRef } from "react";
import Reveal from "@/components/Reveal";
import { PRICING, type PriceTier } from "@/lib/pricing";

const WHATSAPP_NUMBER = "966576785030";

const inputBase =
  "w-full bg-cream rounded-xl px-4 py-3 text-dark text-sm border border-dark/10 outline-none transition-all duration-200 focus:border-honey focus:ring-2 focus:ring-honey/30 placeholder:text-muted/60";

const labelBase = "block text-sm font-bold text-dark mb-1.5";

const totalRowCls =
  "flex items-center justify-between rounded-xl bg-honey/10 border border-honey/30 px-4 py-3";

const totalLabelCls = "text-sm font-bold text-dark";

const totalValueCls = "text-lg font-bold text-honey-deep";

export default function OrderForm() {
  const formRef = useRef<HTMLFormElement>(null);
  const [pkg, setPkg] = useState<PriceTier["id"]>("one");
  const [quantity, setQuantity] = useState(1);

  const selected = PRICING.find((p) => p.id === pkg) ?? PRICING[1];
  const total = selected.price * Math.max(1, quantity);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const form = new FormData(e.target as HTMLFormElement);
    const name = form.get("name") as string;
    const phone = form.get("phone") as string;
    const city = (form.get("city") as string) || "غير محددة";
    const address = (form.get("address") as string) || "غير محددة";
    const notes = (form.get("notes") as string) || "بدون ملاحظات";

    const msg = `🍯 طلب جديد - عسل الطلح البلدي
الباقة: ${selected.label} (${selected.weight})
السعر: ${selected.priceLabel}
الكمية: ${quantity}
المجموع: ${total} دينار
الاسم: ${name}
الجوال: ${phone}
المدينة: ${city}
العنوان: ${address}
ملاحظات: ${notes}`;

    const url = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
    window.open(url, "_blank");
  };

  return (
    <section id="contact" className="py-section relative z-10">
      <div className="container-site">
        <div className="phone-shell">
          <div className="phone-island" />
          <div className="phone-screen">
            <div className="phone-wa">
              <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor" aria-hidden="true"><path d="M12 2a10 10 0 0 0-8.6 15l-1.3 4.7 4.8-1.3A10 10 0 1 0 12 2zm5.8 14.2c-.2.7-1.4 1.3-2 1.4-.5.1-1.2.2-3.8-.8-3.2-1.3-5.2-4.6-5.4-4.8-.2-.2-1.3-1.7-1.3-3.3s.8-2.3 1.1-2.6c.3-.3.6-.4.8-.4h.6c.2 0 .4 0 .6.5l.9 2.1c.1.2.1.4 0 .6l-.4.6c-.2.2-.3.4-.1.7.2.3.9 1.5 2 2.4 1.4 1.2 2.1 1.3 2.4 1.1.3-.2.6-.7.9-1 .2-.2.4-.2.7-.1l2 1c.3.1.5.2.6.3.1.3.1.9-.1 1.4z" /></svg>
              <span className="phone-wa__title">اطلب عبر واتساب</span>
            </div>
            <Reveal>
              <div className="px-6 pt-6">
              <div className="text-center mb-6">
                <span className="label-mustard justify-center">تواصل معنا</span>
                <h2 className="text-2xl md:text-[1.8rem] mt-3 mb-2">اطلب عسل الطلح الآن</h2>
                <p className="text-muted text-sm max-w-lg mx-auto">
                  املأ النموذج وسيتم إرسال طلبك عبر واتساب — فريقنا ينتظرك.
                </p>
              </div>

              <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="name" className={labelBase}>
                    الاسم الكامل <span className="text-honey">*</span>
                  </label>
                  <input
                    id="name"
                    name="name"
                    type="text"
                    required
                    placeholder="أدخل اسمك الكامل"
                    className={inputBase}
                  />
                </div>

                <div>
                  <label htmlFor="phone" className={labelBase}>
                    رقم الجوال <span className="text-honey">*</span>
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="tel"
                    required
                    placeholder="٠٥xxxxxxx"
                    className={inputBase}
                  />
                </div>

                <div>
                  <label htmlFor="city" className={labelBase}>
                    المدينة
                  </label>
                  <input
                    id="city"
                    name="city"
                    type="text"
                    placeholder="مثال: الرياض"
                    className={inputBase}
                  />
                </div>

                <div>
                  <label htmlFor="address" className={labelBase}>
                    العنوان
                  </label>
                  <textarea
                    id="address"
                    name="address"
                    rows={2}
                    placeholder="الحي — الشارع — رقم المبنى"
                    className={inputBase}
                  />
                </div>

                {/* Package selector */}
                <div>
                  <label htmlFor="pkg" className={labelBase}>
                    الباقة
                  </label>
                  <select
                    id="pkg"
                    value={pkg}
                    onChange={(e) => setPkg(e.target.value as PriceTier["id"])}
                    className={inputBase}
                  >
                    {PRICING.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.label} — {t.priceLabel}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Quantity */}
                <div>
                  <label htmlFor="quantity" className={labelBase}>
                    الكمية
                  </label>
                  <input
                    id="quantity"
                    name="quantity"
                    type="number"
                    value={quantity}
                    min={1}
                    onChange={(e) => setQuantity(Math.max(1, Number(e.target.value) || 1))}
                    className={inputBase}
                  />
                </div>

                <div>
                  <label htmlFor="notes" className={labelBase}>
                    ملاحظات
                  </label>
                  <textarea
                    id="notes"
                    name="notes"
                    rows={3}
                    placeholder="أي ملاحظات إضافية؟"
                    className={inputBase}
                  />
                </div>

                {/* Live total */}
                <div className={totalRowCls}>
                  <span className={totalLabelCls}>المجموع</span>
                  <span className={totalValueCls}>{total} دينار</span>
                </div>

                <button type="submit" className="btn-honey w-full text-base py-3.5">
                  إرسال الطلب
                </button>
              </form>

              <p className="text-xs text-muted text-center mt-4">
                سيتم التواصل معك خلال ٢٤ ساعة
              </p>
            </div>
            </Reveal>
            <div className="phone-home" />
          </div>
        </div>
      </div>
    </section>
  );
}
