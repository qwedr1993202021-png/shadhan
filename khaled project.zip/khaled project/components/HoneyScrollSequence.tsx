"use client";

import { useEffect, useRef, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export type SequenceConfig = {
  name: string;
  pathUrl: string; // WebP Sequence Path URL (folder under /public)
  frameCount: number; // Frame Count
};

const HONEY: SequenceConfig = {
  name: "عسل الطلح البلدي",
  pathUrl: "/seq/honey",
  frameCount: 192,
};

// Reveal after enough frames for a smooth start; the rest keep loading in the
// background and getDrawable() covers any frame not yet arrived.
const READY_THRESHOLD = Math.min(40, HONEY.frameCount);

type Props = {
  sequence?: SequenceConfig;
  scrollHeight?: string;
  children?: ReactNode;
};

/** Returns the closest already-loaded frame to `index`, searching outward. */
function getDrawable(
  imgs: HTMLImageElement[],
  index: number,
): HTMLImageElement | undefined {
  const ok = (im?: HTMLImageElement) =>
    !!im && im.complete && im.naturalWidth > 0;
  if (ok(imgs[index])) return imgs[index];
  for (let d = 1; d < imgs.length; d++) {
    if (ok(imgs[index - d])) return imgs[index - d];
    if (ok(imgs[index + d])) return imgs[index + d];
  }
  return undefined;
}

/* ---- Named style constants ---- */

const canvasStyle: CSSProperties = {
  width: "100%",
  height: "100%",
  display: "block",
};

const stickyStyle: CSSProperties = {
  position: "sticky",
  top: 0,
  height: "100dvh",
  overflow: "hidden",
};

const loaderBarTrack: CSSProperties = {
  height: 6,
  width: 192,
  borderRadius: 9999,
  backgroundColor: "rgba(58,45,28,0.1)",
  overflow: "hidden",
};

const loaderBarFillBase: CSSProperties = {
  height: "100%",
  borderRadius: 9999,
  transition: "width 200ms ease",
};

export default function HoneyScrollSequence({
  sequence = HONEY,
  scrollHeight = "300vh",
  children,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const imagesRef = useRef<HTMLImageElement[]>([]);

  const [loadedCount, setLoadedCount] = useState(0);
  const [ready, setReady] = useState(false);

  const { frameCount, pathUrl } = sequence;
  const framePath = (i: number) =>
    `${pathUrl}/frame_${String(i).padStart(4, "0")}.webp`;

  /* ── Effect 1: preload every frame up-front ── */
  useEffect(() => {
    let count = 0;
    const imgs: HTMLImageElement[] = [];

    for (let i = 1; i <= frameCount; i++) {
      const img = new Image();
      img.src = framePath(i);
      img.onload = img.onerror = () => {
        count++;
        setLoadedCount(count);
        if (count >= READY_THRESHOLD) setReady(true);
      };
      imgs.push(img);
    }

    imagesRef.current = imgs;

    // Lock page scroll while frames are loading
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [frameCount, pathUrl]);

  /* ── Effect 2: canvas sizing, rendering & GSAP — only after ready ── */
  useEffect(() => {
    if (!ready) return;

    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    const images = imagesRef.current;
    const state = { frame: 0 };

    const reduce = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches;

    const render = () => {
      const img = getDrawable(images, Math.round(state.frame));
      if (!img) return;
      const cw = canvas.clientWidth;
      const ch = canvas.clientHeight;
      const scale = Math.max(cw / img.width, ch / img.height); // cover
      const dw = img.width * scale;
      const dh = img.height * scale;
      ctx.clearRect(0, 0, cw, ch);
      ctx.drawImage(img, (cw - dw) / 2, (ch - dh) / 2, dw, dh);
    };

    const sizeCanvas = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = canvas.clientWidth;
      const h = canvas.clientHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      render();
    };

    sizeCanvas();
    window.addEventListener("resize", sizeCanvas);

    // Unlock scroll now that the canvas is painted
    document.body.style.overflow = "";

    let trigger: ScrollTrigger | undefined;
    if (!reduce) {
      trigger = ScrollTrigger.create({
        trigger: containerRef.current!,
        start: "top top",
        end: "bottom bottom",
        scrub: 0.5,
        onUpdate: (self) => {
          state.frame = self.progress * (frameCount - 1);
          requestAnimationFrame(render);
        },
      });
      // Re-measure now that the trigger exists
      ScrollTrigger.refresh();
    }

    // Debounced ScrollTrigger.refresh on resize / orientationchange
    let refreshTimer: ReturnType<typeof setTimeout>;
    const debouncedRefresh = () => {
      clearTimeout(refreshTimer);
      refreshTimer = setTimeout(() => ScrollTrigger.refresh(), 250);
    };
    window.addEventListener("resize", debouncedRefresh);
    window.addEventListener("orientationchange", debouncedRefresh);

    return () => {
      window.removeEventListener("resize", sizeCanvas);
      window.removeEventListener("resize", debouncedRefresh);
      window.removeEventListener("orientationchange", debouncedRefresh);
      clearTimeout(refreshTimer);
      trigger?.kill();
    };
  }, [ready, sequence, frameCount]);

  /* ---- Derived values ---- */

  const pct = Math.round((loadedCount / frameCount) * 100);

  const containerStyle: CSSProperties = {
    height: ready ? scrollHeight : "100dvh",
    position: "relative",
  };

  const loaderBarFill: CSSProperties = {
    ...loaderBarFillBase,
    width: `${pct}%`,
    backgroundColor: "#F8CB14",
  };

  const childOverlayStyle: CSSProperties | undefined = children
    ? {
        position: "absolute",
        inset: 0,
        pointerEvents: "none" as const,
      }
    : undefined;

  return (
    <div ref={containerRef} style={containerStyle}>
      <div style={stickyStyle}>
        <canvas
          ref={canvasRef}
          aria-label={sequence.name}
          style={canvasStyle}
        />

        {/* Hero content overlay (CTAs, headline, etc.) */}
        {children && <div style={childOverlayStyle}>{children}</div>}

        {/* Branded loading overlay — clears at threshold, not 100% */}
        {!ready && (
          <div className="absolute inset-0 z-50 grid place-items-center bg-cream">
            <div className="flex flex-col items-center gap-4">
              <div className="text-3xl">🐝</div>
              <div style={loaderBarTrack}>
                <div style={loaderBarFill} />
              </div>
              <span className="text-sm font-bold text-muted">
                جارٍ التحميل {pct}%
              </span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
