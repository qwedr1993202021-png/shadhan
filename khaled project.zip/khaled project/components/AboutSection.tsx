"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import Reveal from "@/components/Reveal";

const stats = [
  { number: "١٠٠٪", label: "طبيعي بلا إضافات" },
  { number: "٤+", label: "جوائز عالمية" },
  { number: "٣", label: "دول كرّمتنا" },
  { number: "٥٠٠جم", label: "عبوة فاخرة" },
];

export default function AboutSection() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [muted, setMuted] = useState(true);
  const toggleSound = () => {
    const v = videoRef.current;
    if (!v) return;
    v.muted = !v.muted;
    setMuted(v.muted);
    if (!v.muted) v.play().catch(() => {});
  };

  return (
    <section id="about" className="py-section relative z-10">
      <div className="container-site">
        <Reveal className="section-panel">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
            {/* Imagery */}
            <div className="w-full lg:flex-[1.6] grid grid-cols-1 gap-4 lg:grid-cols-2 lg:grid-rows-2">
              {/* Brand video — phone story card */}
              <div className="relative mx-auto w-full max-w-[480px] lg:max-w-none aspect-[9/16] lg:row-span-2 rounded-3xl overflow-hidden shadow-lg bg-dark/5">
                <video
                  ref={videoRef}
                  className="absolute inset-0 w-full h-full object-cover"
                  src="/brand/brand-video.mp4"
                  poster="/brand/brand-video-poster.jpg"
                  autoPlay
                  muted
                  loop
                  playsInline
                  preload="metadata"
                />
                <span className="absolute top-3 right-3 text-white/80 text-xs font-medium bg-black/35 backdrop-blur-sm px-2.5 py-1 rounded-full">
                  @shadhan1
                </span>
                <button
                  type="button"
                  onClick={toggleSound}
                  aria-label={muted ? "تشغيل الصوت" : "كتم الصوت"}
                  className="absolute bottom-3 left-3 grid place-items-center w-10 h-10 rounded-full bg-dark/55 text-white backdrop-blur-sm hover:bg-dark/75 transition"
                >
                  {muted ? (
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 001.5 12c0 .898.121 1.768.35 2.595.341 1.24 1.518 1.905 2.659 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06zM17.78 9.22a.75.75 0 10-1.06 1.06L18.44 12l-1.72 1.72a.75.75 0 001.06 1.06l1.72-1.72 1.72 1.72a.75.75 0 101.06-1.06L20.56 12l1.72-1.72a.75.75 0 00-1.06-1.06l-1.72 1.72-1.72-1.72z" />
                    </svg>
                  ) : (
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                      <path d="M13.5 4.06c0-1.336-1.616-2.005-2.56-1.06l-4.5 4.5H4.508c-1.141 0-2.318.664-2.66 1.905A9.76 9.76 0 001.5 12c0 .898.121 1.768.35 2.595.341 1.24 1.518 1.905 2.659 1.905h1.93l4.5 4.5c.945.945 2.561.276 2.561-1.06V4.06zM18.372 8.227a4.293 4.293 0 010 7.546.75.75 0 01-.744-1.302 2.793 2.793 0 000-4.942.75.75 0 01.744-1.302z" />
                    </svg>
                  )}
                </button>
              </div>
              {/* Support photos: side-by-side on mobile, flow into the grid on desktop */}
              <div className="grid grid-cols-2 gap-4 lg:contents">
                <div className="relative aspect-[4/3] lg:aspect-auto lg:h-full rounded-3xl overflow-hidden shadow-md">
                  <Image src="/brand/desert.webp" alt="عسل الطلح من قلب الطبيعة في صحراء المملكة" fill className="object-cover" sizes="(max-width:1024px) 50vw, 25vw" />
                </div>
                <div className="relative aspect-[4/3] lg:aspect-auto lg:h-full rounded-3xl overflow-hidden shadow-md bg-cream">
                  <Image src="/brand/product-jar.jpg" alt="عبوة عسل الطلح البلدي من شدهان" fill className="object-cover" sizes="(max-width:1024px) 50vw, 25vw" />
                </div>
              </div>
            </div>
            {/* Copy */}
            <div className="flex-1 text-center lg:text-right">
              <span className="label-mustard mb-4">قصتنا</span>
              <h2 className="text-3xl md:text-[2.6rem] mb-5 leading-tight">
                من أرض التراث، طعم الأصالة
              </h2>
              <p className="text-muted leading-loose text-base md:text-lg mb-8">
                في <span className="text-dark font-bold">شدهان للعسل</span> نؤمن أن العسل الحقيقي يولد في البرية. نجمع عسل الطلح البلدي من أشجار الطلح البرية في أرض المملكة، ثم نختاره بعناية ونعبئه دون أي معالجة — نقاء أصيل تذوقه في كل قطرة.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {stats.map((s) => (
                  <div key={s.label} className="rounded-2xl bg-cream/60 px-4 py-3 text-center">
                    <div className="text-honey-deep font-extrabold text-2xl">{s.number}</div>
                    <div className="text-muted text-xs mt-1">{s.label}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
