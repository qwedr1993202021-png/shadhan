"use client";

import Reveal from "@/components/Reveal";

export default function Footer() {
  return (
    <footer className="relative z-10 pt-section">
      <div className="container-site">
        <Reveal>
          <div className="text-center bg-dark text-cream rounded-panel p-8 md:p-12 lg:p-16">
            <span className="label-mustard justify-center">اطلب الآن</span>
            <h2 className="text-3xl md:text-[2.8rem] mt-4 mb-4 text-cream">جرّب طعم الأصالة</h2>
            <p className="text-cream/70 max-w-xl mx-auto mb-8 leading-loose">
              عسل الطلح البلدي الفاخر من شدهان — جودة عالمية تصل إلى بابك. تواصل معنا للطلب.
            </p>
            <div className="flex gap-3 justify-center flex-wrap">
              <a href="#contact" className="btn-honey">اطلب عبر النموذج</a>
              <a href="https://instagram.com/shadhan1" className="btn-outline !border-cream/30 !text-cream hover:!border-cream">تابعنا @shadhan1</a>
            </div>
          </div>
        </Reveal>
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 py-10 text-sm text-muted">
          <div className="font-heading font-extrabold text-dark text-lg">شدهان للعسل 🐝</div>
          <p>© ٢٠٢٦ شدهان للعسل — جميع الحقوق محفوظة.</p>
        </div>
      </div>
    </footer>
  );
}
