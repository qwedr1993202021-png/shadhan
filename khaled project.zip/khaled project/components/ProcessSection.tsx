"use client";

import Reveal from "@/components/Reveal";

const steps = [
  { num: "٠١", title: "التربية البرية", text: "نحالنا في أرض الطلح البرية، بعيدًا عن التلوث." },
  { num: "٠٢", title: "الحصاد اليدوي", text: "نجمع العسل يدويًا في وقته المثالي للحفاظ على خواصه." },
  { num: "٠٣", title: "التصفية الطبيعية", text: "دون تسخين أو معالجة — نقاء طبيعي كامل." },
  { num: "٠٤", title: "التعبئة الفاخرة", text: "نعبّئه في عبوات أنيقة تحفظ جودته حتى مائدتك." },
];

export default function ProcessSection() {
  return (
    <section id="process" className="py-section relative z-10">
      <div className="container-site">
        <Reveal className="text-center mb-12">
          <span className="label-mustard justify-center">رحلتنا</span>
          <h2 className="text-3xl md:text-[2.6rem] mt-4">من الخلية إلى مائدتك</h2>
        </Reveal>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {steps.map((s, i) => (
            <Reveal key={s.num} delay={i * 100} className="h-full">
              <div className="section-panel h-full text-center">
                <div className="font-heading text-4xl font-extrabold text-honey-deep mb-3">{s.num}</div>
                <h3 className="text-lg font-extrabold mb-2">{s.title}</h3>
                <p className="text-sm text-muted leading-relaxed">{s.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
