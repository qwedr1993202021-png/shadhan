"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import Reveal from "@/components/Reveal";

const testimonials = [
  {
    quote: "والله يا أخي عسل الطلح البلدي هو الأفضل وأكثر عملائي يمدحونه بحلاوته، جودة ما بعدها جودة.",
    name: "عميل من الرياض",
  },
  {
    quote: "بيض الله وجهك، وصلت. وعسلكم ما شاء الله تبارك الله — مرّة حلو، إن شاء الله أشتري من عندكم دائمًا.",
    name: "عميل من جدة",
  },
  {
    quote: "استخدمت عسل الطلح لعلاج القولون وتقوية المناعة، والنتيجة ممتازة ولله الحمد. أنصح به بكل ثقة.",
    name: "عميلة من الدمام",
  },
  {
    quote: "عسلكم دائمًا أقوله من أفضل أنواع العسل وخلوّكم على هذي الجودة، نسأل الله لكم التوفيق.",
    name: "عميل دائم",
  },
  {
    quote: "جزاكم الله خير، منتجاتكم من أفضل ما استخدمت وكان لها أثر كبير. شكرًا لكم من الأعماق.",
    name: "عميل من مكة",
  },
  {
    quote: "التوصيل سريع والتعامل راقٍ واحترافي. وصل الطلب خلال أقل من يوم، والجودة مميّزة كعادتكم.",
    name: "عميل من أبوظبي",
  },
];

export default function TestimonialsSection() {
  const trackRef = useRef<HTMLDivElement>(null);
  const [reps, setReps] = useState(4);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    const singleSet = track.scrollWidth / reps;
    if (!singleSet) return;
    const perHalf = Math.ceil(window.innerWidth / singleSet) + 1;
    const target = perHalf * 2;
    if (target > reps) setReps(target);
  }, [reps]);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    let tween: gsap.core.Tween | null = null;

    const build = () => {
      tween?.kill();
      gsap.set(track, { x: 0 });
      const half = track.scrollWidth / 2;
      if (half <= 0) return;
      const SPEED = 15;
      tween = gsap.to(track, {
        x: -half,
        duration: half / SPEED,
        ease: "none",
        repeat: -1,
        modifiers: { x: gsap.utils.unitize(gsap.utils.wrap(-half, 0), "px") },
      });
    };

    build();
    (document as any).fonts?.ready?.then(build);

    let resizeTimer: number;
    const onResize = () => {
      clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(build, 200) as unknown as number;
    };
    window.addEventListener("resize", onResize);

    const pause = () => { if (tween) gsap.to(tween, { timeScale: 0, duration: 0.4 }); };
    const play = () => { if (tween) gsap.to(tween, { timeScale: 1, duration: 0.4 }); };
    track.addEventListener("mouseenter", pause);
    track.addEventListener("mouseleave", play);

    return () => {
      window.removeEventListener("resize", onResize);
      track.removeEventListener("mouseenter", pause);
      track.removeEventListener("mouseleave", play);
      tween?.kill();
    };
  }, [reps]);

  const loop = Array.from({ length: reps }).flatMap(() => testimonials);

  return (
    <section id="testimonials" className="pt-[13rem] pb-section relative z-10 overflow-hidden">
      <div className="container-site">
        <Reveal className="text-center mb-12">
          <span className="label-mustard justify-center">آراء عملائنا الكرام</span>
          <h2 className="text-3xl md:text-[2.6rem] mt-4 mb-3">نفخر ونتشرف بكم</h2>
          <p className="text-muted max-w-xl mx-auto">ثقة عملائنا هي أغلى جائزة ننالها.</p>
        </Reveal>
      </div>

      <div className="testi-marquee">
        <div ref={trackRef} className="testi-track">
          {loop.map((t, i) => (
            <article
              key={i}
              className="testi-card bg-surface rounded-2xl p-6 shadow-sm border border-dark/5 flex flex-col h-[290px]"
              aria-hidden={i >= testimonials.length}
            >
              <div className="text-honey text-3xl leading-none mb-2 font-heading font-bold">”</div>
              <p className="text-dark/90 leading-relaxed text-[17px] font-medium mb-4 line-clamp-3 overflow-hidden">{t.quote}</p>
              <div className="flex items-center gap-2 mt-auto">
                <span className="text-[16px] font-bold text-muted">{t.name}</span>
                <span className="text-honey text-lg font-bold">★★★★★</span>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
