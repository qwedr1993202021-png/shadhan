"use client";

export default function OrderButton({
  href = "#contact",
  className = "",
}: { href?: string; className?: string }) {
  return (
    <a href={href} aria-label="اطلب الآن" className={`ob-container ${className}`}>
      <span className="ob-btn">اطلب الان</span>
    </a>
  );
}
