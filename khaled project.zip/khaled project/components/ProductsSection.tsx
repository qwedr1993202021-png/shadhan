"use client";

import Image from "next/image";
import Reveal from "@/components/Reveal";
import { PRICING } from "@/lib/pricing";

const priceCardBase =
  "flex flex-col items-center gap-2 rounded-2xl border p-5 text-center transition-shadow hover:shadow-lg";

const priceCardNormal =
  "bg-white/60 border-dark/10";

const priceCardOffer =
  "bg-honey/10 border-honey ring-2 ring-honey/30";

export default function ProductsSection() {
  return (
    <section id="products" className="py-section relative z-10">
      <div className="container-site">
        <Reveal className="section-panel">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
            {/* Image */}
            <div className="flex-1 w-full max-w-lg mx-auto lg:mx-0">
              <div className="relative w-full aspect-[3/4] rounded-[32px] overflow-hidden shadow-xl bg-cream">
                <Image
                  src="/brand/product-jar.jpg"
                  alt="عبوة عسل الطلح البلدي من شدهان — ٥٠٠ جم"
                  fill
                  className="object-cover"
                  sizes="(max-width: 1024px) 100vw, 40vw"
                />
              </div>
            </div>

            {/* Copy */}
            <div className="flex-1 text-center lg:text-right">
              <Reveal>
                <span className="label-mustard mb-4">منتجنا الفاخر</span>
                <h2 className="text-3xl md:text-[2.6rem] mb-1 leading-tight">عسل الطلح البلدي</h2>
                <p className="font-heading text-base text-mustard font-bold mb-5">Talh Honey</p>
                <p className="text-muted text-base md:text-lg leading-loose mb-6">
                  من أشجار الطلح البرية في أرض المملكة، حائز على جائزة الجودة الذهبية في باريس ولندن — عسل أصلي نقي، بجودة عالمية.
                </p>
              </Reveal>

              <Reveal delay={100}>
                <div className="flex flex-wrap gap-2 mb-6 justify-center lg:justify-start">
                  <span className="text-xs font-bold text-mustard bg-honey/15 rounded-full px-4 py-1.5">الميدالية الذهبية – باريس ٢٠٢٥</span>
                  <span className="text-xs font-bold text-mustard bg-honey/15 rounded-full px-4 py-1.5">البلاتينية – لندن</span>
                  <span className="text-xs font-bold text-mustard bg-honey/15 rounded-full px-4 py-1.5">٥٠٠ جم</span>
                </div>
              </Reveal>
            </div>
          </div>
        </Reveal>

        {/* Price tier cards */}
        <Reveal delay={200}>
          <div className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {PRICING.map((tier) => (
              <div
                key={tier.id}
                className={`${priceCardBase} ${
                  tier.offer ? priceCardOffer : priceCardNormal
                }`}
              >
                {tier.offer && tier.offerLabel && (
                  <span className="text-xs font-bold text-dark bg-honey rounded-full px-3 py-1">
                    {tier.offerLabel}
                  </span>
                )}
                <span className="text-sm text-muted font-bold">{tier.weight}</span>
                <span className="text-base font-bold text-dark">{tier.label}</span>
                <div className="flex items-center gap-2">
                  {tier.compareAt && (
                    <span className="text-sm text-muted line-through">{tier.compareAt}</span>
                  )}
                  <span className="text-xl font-bold text-honey-deep">{tier.priceLabel}</span>
                </div>
                <a
                  href="#contact"
                  className="btn-honey mt-2 text-sm py-2 px-6"
                >
                  اطلب الآن
                </a>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
