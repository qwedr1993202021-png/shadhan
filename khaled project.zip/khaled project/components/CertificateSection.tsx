"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import Reveal from "@/components/Reveal";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
gsap.registerPlugin(ScrollTrigger);

const params = [
  { ar: "الرطوبة", en: "Moisture" },
  { ar: "الفركتوز والجلوكوز", en: "Fructose & Glucose" },
  { ar: "الهيدروكسي ميثيل فورفورال", en: "HMF" },
  { ar: "نشاط إنزيم الدايستيز", en: "Diastase Activity" },
  { ar: "التوصيل الكهربائي", en: "Electrical Conductivity" },
  { ar: "الحموضة الحرة", en: "Free Acidity" },
];

const certificates = [
  { src: "/brand/certs/cert-03.jpg", title: "Paris Honey Awards 2025 — الجودة الذهبية" },
  { src: "/brand/certs/cert-01.jpg", title: "London Honey Awards — البلاتينية" },
  { src: "/brand/certs/cert-02.jpg", title: "Paris Honey Awards" },
  { src: "/brand/certs/cert-09.jpg", title: "شهادة عسل الطلح — الجودة الذهبية (باريس ٢٠٢٥)" },
  { src: "/brand/certs/cert-07.jpg", title: "شهادة عسل السدر — الجودة الذهبية" },
  { src: "/brand/certs/cert-08.jpg", title: "شهادة عسل السمرة — الجودة البلاتينية" },
  { src: "/brand/certs/cert-10.jpg", title: "السدر — البلاتينية + Global Honey Stars" },
  { src: "/brand/certs/cert-05.jpg", title: "شهادة مشاركة — مهرجان وادي ليوا" },
  { src: "/brand/certs/cert-06.jpg", title: "تقرير المختبر — مقاييس الجودة الغذائية" },
  { src: "/brand/certs/cert-04.jpg", title: "اعتمادات واتحادات" },
];

export default function CertificateSection() {
  const [active, setActive] = useState<number | null>(null);
  const pinRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActive(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.body.style.overflow = active !== null ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [active]);

  useEffect(() => {
    const pin = pinRef.current;
    const track = trackRef.current;
    if (!pin || !track) return;
    const ctx = gsap.context(() => {
      const mm = gsap.matchMedia();
      mm.add(
        { isDesktop: "(min-width: 768px)", reduce: "(prefers-reduced-motion: reduce)" },
        (c) => {
          if (!c.conditions?.isDesktop || c.conditions?.reduce) return;
          const getDistance = () => Math.max(0, track.scrollWidth - window.innerWidth);
          gsap.to(track, {
            x: () => -getDistance(),
            ease: "none",
            scrollTrigger: {
              trigger: pin,
              start: "top top",
              end: () => "+=" + getDistance(),
              pin: true,
              pinSpacing: true,
              scrub: 1.5,
              anticipatePin: 1,
              invalidateOnRefresh: true,
              id: "cert-scroll",
            },
          });
        }
      );
    }, pin);
    const refresh = () => ScrollTrigger.refresh();
    window.addEventListener("load", refresh);
    (document as any).fonts?.ready?.then(refresh);
    const t = setTimeout(refresh, 500);

    // Debounced refresh on resize/orientationchange
    let resizeTimer: ReturnType<typeof setTimeout>;
    const debouncedRefresh = () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(refresh, 250);
    };
    window.addEventListener("resize", debouncedRefresh);
    window.addEventListener("orientationchange", debouncedRefresh);

    return () => {
      window.removeEventListener("load", refresh);
      window.removeEventListener("resize", debouncedRefresh);
      window.removeEventListener("orientationchange", debouncedRefresh);
      clearTimeout(resizeTimer);
      clearTimeout(t);
      ctx.revert();
    };
  }, []);

  return (
    <section id="certificate" className="py-section relative z-10">
      <div className="container-site">
        {/* Lab report highlight */}
        <Reveal className="section-panel">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            <div className="flex-1 w-full max-w-sm mx-auto">
              <div className="relative w-full h-[400px] sm:h-[520px] rounded-2xl overflow-hidden shadow-lg">
                <Image src="/brand/lab-certificate.jpg" alt="تقرير مختبر مقاييس الجودة للمنتجات الغذائية لعسل شدهان" fill className="object-cover" sizes="(max-width: 1024px) 90vw, 380px" />
              </div>
            </div>
            <div className="flex-1 text-center lg:text-right">
              <span className="label-mustard mb-4">جودة موثّقة</span>
              <h2 className="text-3xl md:text-[2.6rem] mb-5 leading-tight">مختبريًا معتمد، وعالميًا مكرّم</h2>
              <p className="text-muted text-base md:text-lg mb-8 leading-loose">
                خضع عسل شدهان لفحوصات مخبرية دقيقة في مختبر مقاييس الجودة للمنتجات الغذائية، لتأكيد نقائه ومطابقته للمعايير العالمية لجودة العسل.
              </p>
              <div className="grid grid-cols-2 gap-3">
                {params.map((p) => (
                  <div key={p.en} className="bg-cream rounded-xl px-4 py-3 text-right">
                    <div className="text-sm font-bold text-dark">{p.ar}</div>
                    <div className="font-heading text-[11px] text-muted">{p.en}</div>
                  </div>
                ))}
              </div>
              <p className="text-xs text-muted mt-5">جميع القيم ضمن المعايير القياسية للعسل الطبيعي.</p>
            </div>
          </div>
        </Reveal>

        {/* Certificates gallery */}
        <div ref={pinRef} className="relative md:min-h-[120vh] flex flex-col justify-center gap-8 overflow-hidden">
          <div className="text-center">
            <span className="label-mustard justify-center">موثّق عالميًا</span>
            <h2 className="text-3xl md:text-[2.6rem] mt-4 mb-3">شهاداتنا وجوائزنا</h2>
            <p className="text-muted max-w-2xl mx-auto">مجموعة من الجوائز والشهادات العالمية التي تؤكّد جودة عسل شدهان. اضغط على أي شهادة لعرضها بالحجم الكامل.</p>
            <p className="text-sm text-muted mt-2 hidden md:block">اسحب للأسفل لتصفّح الشهادات</p>
          </div>
          <div ref={trackRef} dir="ltr" className="cert-track-mobile md:flex md:flex-nowrap md:gap-6 md:will-change-transform md:px-[10vw]">
            {certificates.map((c, i) => (
              <div
                key={c.src}
                onClick={() => setActive(i)}
                className="cert-card group shrink-0 w-[300px] bg-surface rounded-2xl border border-dark/5 shadow-sm overflow-hidden cursor-pointer"
              >
                <div className="relative w-full h-52 bg-cream overflow-hidden">
                  <Image
                    src={c.src}
                    alt={c.title}
                    fill
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                    sizes="300px"
                    onLoad={() => { ScrollTrigger.refresh(); }}
                  />
                </div>
                <div className="p-4 text-right">
                  <p className="text-sm font-bold text-dark leading-snug">{c.title}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Lightbox */}
      {active !== null && (
        <div
          className="fixed inset-0 z-[60] bg-dark/85 backdrop-blur-sm flex items-center justify-center p-2 sm:p-6 cursor-zoom-out"
          onClick={() => setActive(null)}
          role="dialog"
          aria-modal="true"
        >
          <div className="relative max-w-3xl max-h-[88vh] w-full sm:w-auto" onClick={(e) => e.stopPropagation()}>
            <Image
              src={certificates[active].src}
              alt={certificates[active].title}
              width={1100}
              height={1400}
              className="w-full sm:w-auto max-h-[80vh] h-auto rounded-xl shadow-2xl object-contain bg-white"
            />
            <p className="text-cream text-center mt-4 font-bold">{certificates[active].title}</p>
            <button
              type="button"
              onClick={() => setActive(null)}
              className="absolute -top-3 -left-3 w-9 h-9 rounded-full bg-honey text-dark font-bold flex items-center justify-center shadow-lg cursor-pointer border-none"
              aria-label="إغلاق"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
