"use client";

import Image from "next/image";
import Reveal from "@/components/Reveal";

const medals = [
  {
    src: "/brand/medal-gold.webp",
    title: "Paris Honey Awards 2025",
    sub: "جائزة الجودة الذهبية",
    note: "عسل الطلح البلدي",
  },
  {
    src: "/brand/medal-london.webp",
    title: "London Honey Awards",
    sub: "الميدالية البلاتينية",
    note: "أعلى تصنيف للجودة",
  },
  {
    src: "/brand/medal-paris.webp",
    title: "Global Honey Stars",
    sub: "نجوم العسل العالمية",
    note: "تقدير دولي للتميّز",
  },
];

export default function AwardsSection() {
  return (
    <section id="awards" className="py-section relative z-10">
      <div className="container-site">
        <Reveal className="text-center mb-12">
          <span className="label-mustard justify-center">تقدير عالمي</span>
          <h2 className="text-3xl md:text-[2.6rem] mt-4 mb-4">حائز على الميداليات الذهبية</h2>
          <p className="text-muted max-w-2xl mx-auto text-base md:text-lg leading-loose">
            نفخر بحصولنا على الميداليات الذهبية في أبرز المسابقات العالمية المقامة في <span className="text-dark font-bold">بريطانيا وفرنسا وأبوظبي</span>، تقديرًا للتميّز والجودة التي نقدّمها.
          </p>
        </Reveal>

        <Reveal className="mb-10">
          <div className="relative w-full rounded-3xl overflow-hidden shadow-md">
            <Image
              src="/brand/awards-banner.png"
              alt="شعارات الجوائز: Paris Honey Awards, London Honey Awards, Global Honey Stars, اتحاد النحالين العرب"
              width={1500}
              height={500}
              className="w-full h-auto object-contain bg-white"
            />
          </div>
        </Reveal>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {medals.map((m, i) => (
            <Reveal key={m.title} delay={i * 100}>
              <div className="section-panel text-center h-full flex flex-col items-center justify-start py-10">
                <div className="relative w-28 h-28 mb-5 animate-float-slower">
                  <Image src={m.src} alt={m.title} fill className="object-contain" sizes="120px" />
                </div>
                <h3 className="text-lg font-extrabold mb-1">{m.sub}</h3>
                <p className="font-heading text-sm text-mustard font-bold mb-2">{m.title}</p>
                <p className="text-sm text-muted">{m.note}</p>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal>
          <div className="relative w-full rounded-3xl overflow-hidden shadow-md">
            <Image
              src="/brand/badge-strip.jpg"
              alt="شعارات الجوائز والاتحادات: مهرجان وادي ليوا، Paris Honey Awards، اتحاد النحالين العرب"
              width={1500}
              height={375}
              className="w-full h-auto object-contain bg-white"
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
