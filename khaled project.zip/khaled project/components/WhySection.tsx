"use client";

import { useState } from "react";
import Image from "next/image";
import Reveal from "@/components/Reveal";

const benefits = [
  {
    img: "/icons/immune.webp",
    title: "يرفع المناعة",
    text: "غني بالعناصر الطبيعية التي تدعم مناعة الجسم.",
  },
  {
    img: "/icons/digestive-system.png",
    title: "مفيد للجهاز الهضمي",
    text: "يساعد على الهضم ويعزّز صحة المعدة بشكل طبيعي.",
  },
  {
    img: "/icons/nature.png",
    title: "طبيعي ١٠٠٪",
    text: "دون أي إضافات أو معالجة — جودة من المصدر، مختار بعناية.",
  },
];

const heroImages = ["/brand/why-talh.jpg", "/brand/why-premium.jpg"];
const heroAlts = [
  "أشجار الطلح البرية — مصدر عسل شدهان الأصيل",
  "عسل شدهان الفاخر — طبيعي ١٠٠٪ مذاق أصيل",
];

export default function WhySection() {
  const [imgIndex, setImgIndex] = useState(0);

  const advanceImage = () => setImgIndex((i) => (i + 1) % heroImages.length);

  return (
    <section className="py-section relative z-10">
      <div className="container-site">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16">
          <Reveal className="flex-1 w-full">
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <div className="relative aspect-square rounded-[32px] overflow-hidden shadow-xl col-span-2">
                {heroImages.map((src, i) => (
                  <Image
                    key={src}
                    src={src}
                    alt={heroAlts[i]}
                    fill
                    className={`object-cover transition-opacity duration-700 ${i === imgIndex ? "opacity-100" : "opacity-0"}`}
                    sizes="(max-width: 1024px) 100vw, 25vw"
                  />
                ))}
                <div className="absolute bottom-0 inset-x-0 h-1 z-10 flex gap-[3px] px-3 pb-2">
                  {heroImages.map((_, i) => (
                    <div key={i} className="flex-1 h-1 rounded-full bg-white/35 overflow-hidden">
                      <div
                        key={`${imgIndex}-${i}`}
                        className={`h-full rounded-full bg-honey ${i === imgIndex ? "progress-active" : "w-0"}`}
                        onAnimationEnd={i === imgIndex ? advanceImage : undefined}
                      />
                    </div>
                  ))}
                </div>
              </div>
              <div className="relative aspect-square rounded-[32px] overflow-hidden shadow-lg">
                <Image src="/brand/why-talh.jpg" alt="أشجار الطلح البرية — مصدر عسل شدهان الأصيل" fill className="object-cover" sizes="(max-width: 1024px) 50vw, 12vw" />
              </div>
              <div className="relative aspect-square rounded-[32px] overflow-hidden shadow-lg bg-cream flex items-center justify-center p-6">
                <span className="font-heading text-4xl font-extrabold text-honey text-center leading-tight">طبيعي<br/>١٠٠٪</span>
              </div>
            </div>
          </Reveal>

          <div className="flex-1 text-center lg:text-right">
            <Reveal>
              <span className="label-mustard mb-4">لماذا شدهان؟</span>
              <h2 className="text-3xl md:text-[2.6rem] mb-3 leading-tight">لماذا عسل الطلح من شدهان؟</h2>
              <p className="text-muted text-base md:text-lg mb-8 leading-loose">استثمر في صحتك بمنتج مضمون — عسل طبيعي بمذاق أصيل وجودة موثّقة.</p>
            </Reveal>
            <div className="space-y-4">
              {benefits.map((b, i) => (
                <Reveal key={b.title} delay={i * 100}>
                  <div className="glass-card rounded-2xl p-5 flex items-start gap-4 text-right">
                    <div className="relative w-10 h-10 shrink-0 mt-0.5">
                      <Image src={b.img} alt="" fill className="object-contain" sizes="40px" />
                    </div>
                    <div>
                      <h3 className="text-lg font-extrabold mb-1">{b.title}</h3>
                      <p className="text-sm text-muted leading-relaxed">{b.text}</p>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
